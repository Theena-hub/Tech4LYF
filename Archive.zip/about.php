<!DOCTYPE html>
<html lang="en">
<?php include("head.php"); ?>
<link rel="stylesheet" href="css/about.css">

<body>
<?php include 'nav.php';?>
    <div class="">
        <div class="container-fluid about_session" style="margin:auto;">
            <div class="container ab_container">
                
                <div class="row ab_row">
                    <div class="col-md-7 about_session1"  style="margin:auto;">
                        <div class="ab_session ">
                            <div class="ab_con">About Us</div>
                            <div class="session_head">
                              <p>Explore the Enthusiastic 
                                souls here at T4L </p>
                            </div>
                            <div class="session_head1">
                                <p>We at Tech4Lyf empathize your needs and serve with full
                                    heart to porvide good softwares for you lorrem ipsum is a</p>
                            </div>
                            <div class="">
                                
                            </div>
                        </div>    
            
                    </div>
                    <div class="col-md-5 about_img" style=>
                      </div>
                    </div>  
                    <img class="img-fluid" style="width:80%" src="img\handim (1).png">
                
            </div>
        </div>
        <div class="about_session2">
    
            <!-- <div class=""> -->
                <div class="row ab-session2">
            
                    <div class="col-md-6 session_img1">          
                        <img class="img-fluid" src="img\about_circle.png">
                    </div>
                    <div class="col-md-6" style="margin: auto;">
                        <div class="founder">
                            <h5 class="founder-head">Our Founder’s speak</h5>
    
                            <img class="img-fluid" src="img\about 2.png">
                        </div>
                    </div>
                </div>   
            <!-- </div>         -->
        </div>  
        
        <div class="about-session3">
            <div class="row ab-session3" style="margin:0; padding: 42px 0px;
background: rgba(224, 64, 72, 0.07);">
                <div class="session3-session col-md-4">
                    <div class="session3-img"style="justify-content:center;">
                        <img class="img-fluid" src="img\Group1.png">
                        <h5>24/7 Support</h5>
                        <p>Not only developing the product we 
                            love to support you forever.</p>
                    </div>
    
                </div>
                <div class="session3-session col-md-4">
                    <div class="session3-img">
                        <img class="img-fluid"  src="img\img2.png">
                        <h5>99.99 % Availability</h5>
                        <p>As a Best Hosting Reseller, We promise 
                            99.9% Availability of your Products</p>
                    </div>
    
                </div>
                <div class="session3-session col-md-4">
                    <div class="session3-img" >
                        <img class="img-fluid"  src="img\img33.png">
                        <h5>Training sessions</h5>
                        <p>Our team of experts trains you in your 
                            product and they always love to 
                            hear queries from you.</p>
                    </div>
    
                </div>
            </div>
        </div>
    
       
        <div class="container about-session5">
            <div class="session5-head" style="padding:15px">
                <h5>We are top rated </h5>
                <h6>Just take a look at what our clients say about us. We thank them a lot for top ranking us and for using our solutions.</h6>            
            </div> 
            <div class="container section-padding">
              <div class="screenshot_slider owl-carousel">
                <div class="item">
                  <div class="flex-box">
                    <img src="img\circleimg1.svg" style=" " alt="" title="">
                    <h3>Subramni</h3>
                    <div class="single-start" style="display: flex;justify-content: center;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">                    
                    </div>
                    <p class="">Once we achieve a 100% result in the above phases, we seek feedback and reviewsfrom our project manager. Upon sanctioning, your final software will be launched in the market with highly enabled safety and security options.</p>
                  </div>
                </div>
                <div class="item">
                  <div class="flex-box">
                    <img src="img\circleimg1.svg" style=" " alt="" title="">
                    <h3>Subramni</h3>
                    <div class="single-start" style="display: flex;justify-content: center;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">                      
                    </div>
                    <p class="" >Once we achieve a 100% result in the above 
                      phases, we seek feedback and reviewsfrom our 
                      project manager. Upon sanctioning, your final 
                      software will be launched in the market with highly 
                      enabled safety and security options.
                      </p>
                  </div>
                </div>
                <div class="item">
                  <div class="flex-box">
                    <img src="img\circleimg1.svg" style=" " alt="" title="">
                    <h3>Subramni</h3>
                    <div class="single-start" style="display: flex;justify-content: center;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      <img class="img-fluid" src="img\Star 16.svg" style="width:25px;height:auto;">
                      
                    </div>
                    <p class="">Once we achieve a 100% result in the above 
                      phases, we seek feedback and reviewsfrom our 
                      project manager. Upon sanctioning, your final 
                      software will be launched in the market with highly 
                      enabled safety and security options.
                      </p>
                  </div>
                </div>              
              </div>
            </div>     
        </div>
          <?php include("footer.php")?>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.0/anime.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   <script src="js\about.js"></script>
</body>
</html>